The file contains all URL to the static website and bucket name as well.

URLS: 1) http://my-106867806811-bucket.s3-website-us-east-1.amazonaws.com/index.html
      2) DNS -  https://d2pwncnnx2raz4.cloudfront.net/
      3) http://my-106867806811-bucket.s3-website-us-east-1.amazonaws.com/

Bucket name: http://my-106867806811-bucket.s3-website-us-east-1.amazonaws.com/